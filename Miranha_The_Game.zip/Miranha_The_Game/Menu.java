import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author Eduardo Cardoso Agostinetti
 * @version 30.03.2023
 */
public class Menu extends World
{
    Flecha flecha = new Flecha();
    Jogar jogar = new Jogar();
    private int opcao = 0;
    
    /**
     * Constructor for objects of class Jogo.
     * 
     */
    public Menu()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepararMundo();
        
    }
    
    /**Metodo que adiciona 3 atores no mundo,
     * que vão servir de referencia para o menu do jogo.
     * @author Eduardo Cardoso Agostinetti
     */
    public void prepararMundo()
    {
        addObject(new Jogar(),300,150);
        addObject(new Opcoes(), 310,220);
        addObject(flecha, 230,150);
    }
    
    /**
     * Act - do whatever the Jogar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     * Metodo usado para direcionar o ator seta no menu para pressionar ao escolher opção.
     * @author Eduardo Cardoso Agostinetti
     */
    public void act(){
        Greenfoot.setSpeed(50);
    if(Greenfoot.isKeyDown("UP") && opcao != 0){opcao++;}
    if(Greenfoot.isKeyDown("DOWN") && opcao != 1){opcao--;}
    
    if(opcao >= 2){opcao = 0;}
    if(opcao<0){ opcao = 1;}
    
    flecha.setLocation(230, 150 + (opcao * 70));
    
    if(Greenfoot.isKeyDown("ENTER")){
    switch(opcao){
        case 0: 
            Greenfoot.setWorld(new Jogo());
            break;
        case 1:
            Greenfoot.setWorld(new Config());
            break;

    }
    }
    }
}
