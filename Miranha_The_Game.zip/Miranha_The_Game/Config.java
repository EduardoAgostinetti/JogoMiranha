import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Config here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Config extends World
{
    int opcao = 10;
     maryjane mj = new maryjane();
     /**
     * Constructor for objects of class Jogo.
     * 
     */
    public Config()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        GreenfootImage img = new GreenfootImage("backgroundconfig.png");
        setBackground(img);
       
        
        
        
    }
    
    /**
     * Act - do whatever the Jogar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     * Metodo usado para configurar a velocidade do jogo e encaminha para o jogo.
     * @author Eduardo Cardoso Agostinetti
     */
    public void act(){
        if(Greenfoot.isKeyDown("-")){opcao= 0;}
        if(Greenfoot.isKeyDown("+")){opcao= 1;}
        if(Greenfoot.isKeyDown("p")){opcao= 2;}
        
        switch(opcao){
            
        case 0:
            Greenfoot.setSpeed(45);
            showText(" Velocidade diminuida", 150, 380);
            break;
        case 1:
            Greenfoot.setSpeed(55);
            showText(" Velocidade aumentada", 150, 380);
            break;
        case 2:
             Greenfoot.setWorld(new Jogo());
            
        }
        
    }
    
}  
 
    
        