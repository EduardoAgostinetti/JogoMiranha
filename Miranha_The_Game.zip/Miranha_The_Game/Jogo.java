import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author Eduardo Cardoso Agostinetti
 * @version 30.03.2023
 */
public class Jogo extends World
{

    /**
     * Constructor for objects of class Jogo.
     * 
     */
    public Jogo()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        
        GreenfootImage img = new GreenfootImage("background.png");
        setBackground(img);
        
        miranha bs = new miranha();
        duende dd = new duende();
        octopus oc = new octopus();
        maryjane mj = new maryjane();
        addObject(dd,100,80);
        addObject(bs,300,350);
        addObject(oc,500,80);
        addObject(mj,300,80);
    }
    /**
     * Act - do whatever the Jogar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     * Metodo usado para voltar ao menu do jogo, criando um novo mundo "menu"
     * @author Eduardo Cardoso Agostinetti
     */
    public void act(){
    if(Greenfoot.isKeyDown("x")){Greenfoot.setWorld(new Menu());}
    }
}
