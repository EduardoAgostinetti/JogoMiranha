import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Jogar here.
 * 
 * @author Eduardo Cardoso Agostinetti
 * @version 30.03.2023
 */
public class Jogar extends Actor
{
    /**
     * Act - do whatever the Jogar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
