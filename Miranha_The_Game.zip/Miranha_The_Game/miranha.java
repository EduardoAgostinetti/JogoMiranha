import greenfoot.*;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

/**
 * Write a description of class miranha here.
 * 
 * @author Eduardo Cardoso Agostinetti
 * @version (30.03.2023)
 */
public class miranha extends Actor
{
    int qtd;    
    
    /**
     * Act - do whatever the octopus wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     * Método chamado a todo momento que o ator esta no mundo,
     * para andar com o persanagem e trocar a sprite do ator.
     * @author Eduardo Cardoso Agostinetti
     */
    public void act()
    {
       if(Greenfoot.isKeyDown("left")){
           
            setImage("miranhaLeft.png");
            setLocation(getX() - 5, getY());
            
        }else if(Greenfoot.isKeyDown("right")){
            
            setImage("miranhaRight.png");
            setLocation(getX() + 5, getY());
             
        }else if(Greenfoot.isKeyDown("up")){
            setImage("miranhaUp.png");         
            setLocation(getX(), getY() - 5);
             
        }else if(Greenfoot.isKeyDown("down")){
            setImage("miranhaDown.png"); 
            setLocation(getX(), getY() + 5);  
             
        }
         
         salvarMaryjane();
    }
    /**Método para remoção e adição randomica do Ator maryjane, 
     * juntamente com a contagem de pontos exibida no jogo e
     * a criação de um arquivo .txt que armazena o Score feito na jogada.
     * @author Eduardo Cardoso Agostinetti
     */
    public void salvarMaryjane(){
         
        if(isTouching(maryjane.class)){
            removeTouching(maryjane.class);
            qtd = qtd + 1;
            getWorld().showText("Salvou: " + qtd, 300, 20);           
             maryjane mj = new maryjane();
             //getWorld().addObject(mj,Greenfoot.getRandomNumber(600),Greenfoot.getRandomNumber(400));
               
             Random rand = new Random();
             int randomNumber = generateRandomNumber(3, rand);

             getWorld().addObject(mj,getRandomNumberRecursivo(10, 590),randomNumber);
                

                 
              try {
                  File myObj = new File("C:\\Users\\labinfo\\Desktop\\Miranha_The_Game\\Scores\\Score.txt");
                  if (myObj.createNewFile()) {
            
                   
                    FileWriter fileWriter = new FileWriter(myObj, false);
                    PrintWriter printWriter = new PrintWriter(fileWriter);
                    printWriter.println("Score:" + qtd);
                    printWriter.flush();
                    printWriter.close();
                    
                  } else {
                      
                    FileWriter fileWriter = new FileWriter(myObj, false);
                    PrintWriter printWriter = new PrintWriter(fileWriter);
                    printWriter.println("Score:" + qtd);
                    printWriter.flush();
                    printWriter.close();
                
                    
                  }
                    } catch (IOException e) {
                      e.printStackTrace();
                }  
             
            }
    }
    
    /**Método recursivo que gera um numero randomico que serve de cordena X para posicionar o ator "maryjane"
     * @author Eduardo Cardoso Agostinetti
     */
     private static int getRandomNumberRecursivo(int min, int max) {
      Random random = new Random();
      int number = random.nextInt((max - min) + 1) + min;
      if (number == min) {
         return getRandomNumberRecursivo(min, max);
      }
      return number;
   }
   
   /**Método recursivo tail que gera um numero randomico que serve de cordena Y para posicionar o ator "maryjane"
     * @author Eduardo Cardoso Agostinetti
     */
        public static int generateRandomNumber(int n, Random rand) {
        if (n == 1) {
            return rand.nextInt(10);
        } else {
            return generateRandomNumber(n - 1, rand) * 8 + rand.nextInt(10);
        }
    }  
}
