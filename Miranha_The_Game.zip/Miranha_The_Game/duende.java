import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)



/**
 * Write a description of class duende here.
 * 
 * @author Eduardo Cardoso Agostinetti
 * @version 30.03.2023
 */
public class duende extends Actor
{
    String arquivo;
    /**
     * Act - do whatever the octopus wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     * Metodo para movimentar o ator "octopus" em direções randomicas
     * @author Eduardo Cardoso Agostinetti
     * @version 30.03.2023
     */
    public void act()
    {
        move(4);
       if (Greenfoot.getRandomNumber(100) < 10)
       {
           turn(Greenfoot.getRandomNumber(15) + 30);
           matarMiranha();
       }
    }
    
    /**
     * Metodo para realizar a suposta morte do miranha, quando o ator toca na class miranha.class
     * irá remover o ator da class e mostrar uma imagem na tela dizendo 
     * "Game over,pressione 'X' para sair".
     * @author Eduardo Cardoso Agostinetti
     * @version 30.03.2023
     */
    public void matarMiranha()
    {
        if(isTouching(miranha.class)){
        
        removeTouching(miranha.class);
        getWorld().showText("Game over, pressione 'X' para sair",300,200);

        
        }
    }
}
